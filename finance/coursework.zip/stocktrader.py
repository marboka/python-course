"""
stocktrader -- A Python module for virtual stock trading
TODO: Add a description of the module...
Also fill out the personal fields below.

Full name: Peter Pan
StudentId: 123456
Email: peter.pan@student.manchester.ac.uk
"""

class TransactionError(Exception):
    pass

class DateError(Exception):
    pass

stocks = {}
portfolio = {}
transactions = []

def normaliseDate(s): 
    # TODO
    return

# TODO: All other functions from the tasks go here

def main():
    # Test your functions here
    return

# the following allows your module to be run as a program
if __name__ == '__main__' or __name__ == 'builtins':
    main()